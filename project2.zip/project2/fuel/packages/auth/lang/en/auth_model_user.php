<?php

return array(
    'name'     => 'User name',
    'email'    => 'Email address',
    'password' => 'Password',
    'group_id' => 'Group',
);
