<?php
return array(
    'sql_max_timestamp_mysql' => '2038-01-18 22:14:08',
    'sql_max_timestamp_unix'  => 2147483647,
);
