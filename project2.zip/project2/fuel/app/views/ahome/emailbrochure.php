
Hello <?php echo $email_data['fullname']; ?> !<br>
This is an confirmation for your recent order.<br><br>
You have ordered a travel brochure for the state:<br>
<?php echo $email_data['order'] ; ?>
<br><br>
Your order would be shipped to the address:<br>
<?php echo $email_data['address'];?>
<br><br>
Thanks for shopping at CT310!
