 
<?php foreach ($attractions as $attraction): ?>
 
    <h3><?php echo Html::anchor('ahome/view/'.$attraction->id, $attraction->title) ?></h3>
     
    <p><?php echo $attraction->summary ?></p>
 
<?php endforeach; ?>
