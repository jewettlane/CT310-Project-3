
<div class="row">
	<div class="col-md-3">
		<?php echo Form::open(array()); ?>
			
			<div class="form-group">
				
				<label for="postaladdress">Select Brochure</label>
				
				<?php echo Form::select('brochurename', 'none', array(
					
					'Kansas' => 'Kansas',
					'Michigan' => 'Michigan'
				),
				array('class' => 'form-control')); ?>
				<br>
				<label for="fullname">Your Name</label>
				<?php echo Form::input('fullname', Input::post('fullname'), array('class' => 'form-control', 'placeholder' => 'Postal Address', 'autofocus')); ?>
				<br>
	
				<label for="postaladdress">Your Postal Address</label>
				<?php echo Form::textarea('postaladdress', Input::post('postaladdress'), array('class' => 'form-control', 'placeholder' => 'Postal Address', 'autofocus')); ?>

				
			</div>

			

			<div class="actions">
				<?php echo Form::submit(array('value'=>'Buy Now', 'name'=>'submit', 'class' => 'btn btn-lg btn-primary btn-block')); ?>
			</div>

		<?php echo Form::close(); ?>
	</div>
</div>
