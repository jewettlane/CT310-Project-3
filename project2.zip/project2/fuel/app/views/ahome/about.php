
    <p>This is a website created for Project 2 for the course CT310. It presents travel attractions across the US states. This is not an official website and is only a student project. We have 2 group members: Abhimanyu and Jewett!</p>
    
    
    
    <p><b>Abhi says:</b></p>
    <blockquote>Hi! I'm Abhi. I'm a graduate student at CSU and I love messing up with servers and workstations! </blockquote>
    
    <p><b>Jewett says:</b></p>
    <blockquote>Hey, I'm Jewett. I'm a junior at CSU and majoring in Applied Computing Technologies. I play lots of video games and I really like pasta! </blockquote>

