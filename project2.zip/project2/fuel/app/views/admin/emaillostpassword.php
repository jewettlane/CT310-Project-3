Hello <?php echo $email_data['name']; ?> !<br>
It seems you or someone on your behalf, requested to reset your password.<br>
If you feel this is genuine, please click on the following link to reset your password.

<br><br>
<?php echo $email_data['link'] ; ?>
<br><br>
This is a single-use use URL and good for just 24 hours.
<br><br>
Thanks for using the CT310 Project2 website!
