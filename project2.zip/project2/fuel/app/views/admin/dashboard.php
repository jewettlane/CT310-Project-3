<div class="jumbotron">
	<h2>Welcome!</h2>
	<p>This is the admin dashboard for CT310 Project2.<br>
	The top navigation bar lets you fully control this travel website.
	</p>
	
</div>
<div class="row">
	<div class="col-md-4">
		<h2>Attractions</h2>
		<p>This section allows you to create new travel attractions. It also lets you edit existing attractions or even delete the ones you do not like!</p>
		
	</div>
	<div class="col-md-4">
		<h2>Comments</h2>
		<p>Someone posted a nasty comment? No problem, you can delete or edit it here!		
	</div>
	<div class="col-md-4">
		<h2>States</h2>
		<p>Add or remove US states in this area.</p>
		
	</div>
</div>
