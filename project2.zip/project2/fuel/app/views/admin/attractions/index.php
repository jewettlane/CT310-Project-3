<h2>Listing Attractions</h2>
<br>
<?php if ($attractions): ?>
<table class="table table-striped">
	<thead>
		<tr>
			<th>Title</th>
			<th>Id</th>
			<th>Image url</th>
			<th>Summary</th>
			<th>Body</th>
			<th>State id</th>
			<th>User id</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($attractions as $item): ?>		<tr>

			<td><?php echo $item->title; ?></td>
			<td><?php echo $item->id; ?></td>
			<td><?php echo $item->image_url; ?></td>
			<td><?php echo $item->summary; ?></td>
			<td><?php echo $item->body; ?></td>
			<td><?php echo $item->state_id; ?></td>
			<td><?php echo $item->user_id; ?></td>
			<td>
				<?php echo Html::anchor('admin/attractions/view/'.$item->id, 'View'); ?> |
				<?php echo Html::anchor('admin/attractions/edit/'.$item->id, 'Edit'); ?> |
				<?php echo Html::anchor('admin/attractions/delete/'.$item->id, 'Delete', array('onclick' => "return confirm('Are you sure?')")); ?>

			</td>
		</tr>
<?php endforeach; ?>	</tbody>
</table>

<?php else: ?>
<p>No Attractions.</p>

<?php endif; ?><p>
	<?php echo Html::anchor('admin/attractions/create', 'Add new Attraction', array('class' => 'btn btn-success')); ?>

</p>
