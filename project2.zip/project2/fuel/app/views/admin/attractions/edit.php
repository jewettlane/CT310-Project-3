<h2>Editing Attraction</h2>
<br>

<?php echo render('admin/attractions/_form'); ?>
<p>
	<?php echo Html::anchor('admin/attractions/view/'.$attraction->id, 'View'); ?> |
	<?php echo Html::anchor('admin/attractions', 'Back'); ?></p>
