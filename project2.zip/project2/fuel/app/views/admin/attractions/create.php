<h2>New Attraction</h2>
<br>

<?php echo render('admin/attractions/_form'); ?>


<p><?php echo Html::anchor('admin/attractions', 'Back'); ?></p>
