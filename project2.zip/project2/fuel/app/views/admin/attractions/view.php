<h2>Viewing #<?php echo $attraction->id; ?></h2>

<p>
	<strong>Title:</strong>
	<?php echo $attraction->title; ?></p>
<p>
	<strong>Id:</strong>
	<?php echo $attraction->id; ?></p>
<p>
	<strong>Image url:</strong>
	<?php echo $attraction->image_url; ?></p>
<p>
	<strong>Summary:</strong>
	<?php echo $attraction->summary; ?></p>
<p>
	<strong>Body:</strong>
	<?php echo $attraction->body; ?></p>
<p>
	<strong>State id:</strong>
	<?php echo $attraction->state_id; ?></p>
<p>
	<strong>User id:</strong>
	<?php echo $attraction->user_id; ?></p>

<?php echo Html::anchor('admin/attractions/edit/'.$attraction->id, 'Edit'); ?> |
<?php echo Html::anchor('admin/attractions', 'Back'); ?>