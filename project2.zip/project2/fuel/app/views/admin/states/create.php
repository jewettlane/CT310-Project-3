<h2>New State</h2>
<br>

<?php echo render('admin/states/_form'); ?>


<p><?php echo Html::anchor('admin/states', 'Back'); ?></p>
