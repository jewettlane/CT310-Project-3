<h2>Listing States</h2>
<br>
<?php if ($states): ?>
<table class="table table-striped">
	<thead>
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($states as $item): ?>		<tr>

			<td><?php echo $item->id; ?></td>
			<td><?php echo $item->name; ?></td>
			<td>
				<?php echo Html::anchor('admin/states/view/'.$item->id, 'View'); ?> |
				<?php echo Html::anchor('admin/states/edit/'.$item->id, 'Edit'); ?> |
				<?php echo Html::anchor('admin/states/delete/'.$item->id, 'Delete', array('onclick' => "return confirm('Are you sure?')")); ?>

			</td>
		</tr>
<?php endforeach; ?>	</tbody>
</table>

<?php else: ?>
<p>No States.</p>

<?php endif; ?><p>
	<?php echo Html::anchor('admin/states/create', 'Add new State', array('class' => 'btn btn-success')); ?>

</p>
