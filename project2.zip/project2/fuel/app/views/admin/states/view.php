<h2>Viewing #<?php echo $state->id; ?></h2>

<p>
	<strong>Id:</strong>
	<?php echo $state->id; ?></p>
<p>
	<strong>Name:</strong>
	<?php echo $state->name; ?></p>

<?php echo Html::anchor('admin/states/edit/'.$state->id, 'Edit'); ?> |
<?php echo Html::anchor('admin/states', 'Back'); ?>