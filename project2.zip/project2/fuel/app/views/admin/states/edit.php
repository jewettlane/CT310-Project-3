<h2>Editing State</h2>
<br>

<?php echo render('admin/states/_form'); ?>
<p>
	<?php echo Html::anchor('admin/states/view/'.$state->id, 'View'); ?> |
	<?php echo Html::anchor('admin/states', 'Back'); ?></p>
