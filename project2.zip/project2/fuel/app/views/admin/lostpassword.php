<div class="row">
	<div class="col-md-3">
		<?php echo Form::open(array()); ?>
			
			<div class="form-group">
				<label for="email">Registered Email:</label>
				<?php echo Form::input('email', Input::post('email'), array('class' => 'form-control', 'placeholder' => 'Email', 'autofocus')); ?>

				
			</div>

			

			<div class="actions">
				<?php echo Form::submit(array('value'=>'Submit', 'name'=>'submit', 'class' => 'btn btn-lg btn-primary btn-block')); ?>
			</div>

		<?php echo Form::close(); ?>
	</div>
</div>
