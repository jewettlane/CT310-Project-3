<?php

class Controller_Admin extends Controller_Base
{
	public $template = 'admin/template';

	public function before()
	{
		parent::before();

		if (Request::active()->controller !== 'Controller_Admin' or ! in_array(Request::active()->action, array('login', 'logout','lostpassword','changepassword')))
		{
			if (Auth::check())
			{
				$admin_group_id = Config::get('auth.driver', 'Simpleauth') == 'Ormauth' ? 6 : 100;
				if ( ! Auth::member($admin_group_id))
				{
					Session::set_flash('error', e('You don\'t have access to the admin panel'));
					Response::redirect('ahome');
				}
			}
			else
			{
				Response::redirect('admin/login');
			}
		}
	}

	public function action_login()
	{
		// Already logged in
		Auth::check() and Response::redirect('admin');

		$val = Validation::forge();

		if (Input::method() == 'POST')
		{
			$val->add('email', 'Email or Username')
			    ->add_rule('required');
			$val->add('password', 'Password')
			    ->add_rule('required');

			if ($val->run())
			{
				if ( ! Auth::check())
				{
					if (Auth::login(Input::post('email'), Input::post('password')))
					{
						// assign the user id that lasted updated this record
						foreach (\Auth::verified() as $driver)
						{
							if (($id = $driver->get_user_id()) !== false)
							{
								// credentials ok, go right in
								$current_user = Model\Auth_User::find($id[1]);
								Session::set_flash('success', e('Welcome, '.$current_user->username));
								Response::redirect('admin');
							}
						}
					}
					else
					{
						$this->template->set_global('login_error', 'Login failed!');
					}
				}
				else
				{
					$this->template->set_global('login_error', 'Already logged in!');
				}
			}
		}

		$this->template->title = 'Login';
		$this->template->content = View::forge('admin/login', array('val' => $val), false);
	}

	public function action_lostpassword($hash = null)
	{
		// was the lostpassword form posted?
		if (\Input::method() == 'POST')
		{
			// do we have a posted email address?
			if ($email = \Input::post('email'))
			{
				// lookup user via email from the database
				if ($user = \Model\Auth_User::find_by_email($email))
				{
					// generate a recovery hash
					$hash = \Auth::instance()->hash_lost_password(\Str::random()).$user->id;
	
					// and store it in the user profile
					\Auth::update_user(
						array(
							'lostpassword_hash' => $hash,
							'lostpassword_created' => time()
						),
						$user->username
					);
	
					// send an email out with a reset link
					\Package::load('email');
					$email = \Email::forge();
					$email_data = array();
					$email->from('admin@gmail.com', 'CT310 Admin'); 
					$email->to($user->email, $user->username);
					$email->subject('CT310 Project2 Reset Password');
					
					$email_data['link'] = Uri::create('admin/lostpassword/' . base64_encode($hash) . '/');
					$email_data['name'] = $user->username;
					
					$email->html_body(\View::forge('admin/emaillostpassword', array('email_data' => $email_data)));					
					// Try sending email
					try
					{
						// send the email
						$email->send();
					}
	
					// in case something is wrong
					catch(\EmailValidationFailedException $e)
					{
					
					Session::set_flash('error', e('Invalid email address!'));
					\Response::redirect('ahome');
					}
	
					// what went wrong now?
					catch(\Exception $e)
					{
						
					// Display message 
					Session::set_flash('error', e('Error sending email!'));
					\Response::redirect('ahome');
					}
				}
				
			}
	
			// posted form, but email address posted?
			else
			{
				// inform the user and fall through to the form
				Session::set_flash('error', e('No email entered'));
				\Response::redirect('ahome');

			}
	
			// inform the user that email has been sent
			Session::set_flash('success', e('Password reset link sent in email'));
			\Response::redirect('ahome');
		}
	
		// no form posted, do we have a hash passed in the URL?
		elseif ($hash !== null)
		{
		
			// decode the hash
			$hash = base64_decode($hash);
			echo $hash;
			echo '<br>';
			// get the userid from the hash
			$user = substr($hash, 44);
			echo $user;
			// and find the user with this id
			if ($user = \Model\Auth_User::find_by_id($user))
			{
				// do we have this hash for this user, and hasn't it expired yet (we allow for 24 hours response)?
				
				if (isset($user->profile_fields ["lostpassword_hash"]) and $user->profile_fields ["lostpassword_hash"] == $hash and time() - $user->profile_fields ["lostpassword_created"] < 86400)
				{
					echo '<p> Hash found </p>';
					// invalidate the hash
					\Auth::update_user(
						array(
							'lostpassword_hash' => null,
							'lostpassword_created' => null,
							
						),
						$user->username
										
					);
					
					// log the user in send them to the form to change the password
					if (\Auth::instance()->force_login($user->id))
					{
						
						\Response::redirect('admin/changepassword');
						
					}
				}
			}
	
			// wrong hash?
			
			Session::set_flash('error', e('Invalid hash!'));
			\Response::redirect('ahome');
		}
	
		// no form posted, and no hash present
		//else
		//{
			//Session::set_flash('error', e('Unknown error!'));
			//\Response::redirect('admin/lostpassword');
			
		//}
	
		
			$this->template->title = 'Lost Password';
			$this->template->content = View::forge('admin/lostpassword');	
			
	}
	
	public function action_changepassword()
	{
		$this->template->title = 'Change Password';
		$this->template->content = View::forge('admin/changepassword');

		if ( ! Auth::check())
		{
			Response::redirect('ahome');
		}

		if (\Input::method() == 'POST')
		{
		
		
       		 // do we have a posted new password?
        		if ($newpass = \Input::post('newpassword'))
        			{
		
					$username = Auth::get('username');
					$newpass = Auth::hash_password($newpass);
					DB::update('users')->value('password',$newpass)->where('username','=',$username)->execute();
					Session::set_flash('success', e('Password reset succesfully!'));
					Response::redirect('ahome');
				}
		}
	}
	
	
	
	/**
	 * The logout action.
	 *
	 * @access  public
	 * @return  void
	 */
	public function action_logout()
	{
		Auth::logout();
		Response::redirect('admin');
	}

	/**
	 * The index action.
	 *
	 * @access  public
	 * @return  void
	 */
	public function action_index()
	{
		$this->template->title = 'Dashboard';
		$this->template->content = View::forge('admin/dashboard');
	}

}

/* End of file admin.php */
