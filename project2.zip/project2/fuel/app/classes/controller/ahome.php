<?php

class Controller_Ahome extends Controller_Base
{
    
	
	public function action_index()
    {
        $view = View::forge('ahome/index');
         
        $view->attractions = Model_Attraction::find('all');
         
        $this->template->title = 'Travel Attractions';
        $this->template->content = $view;
    }
	public function action_view($id)
	{
		$attraction = Model_Attraction::find_by_id($id, array('related' => array('user', 'comments')));
		
		$this->template->title = $attraction->title;
		$this->template->content = View::forge('ahome/view', array(
			'attraction' => $attraction,
		));
	}
	
	public function action_about()
    {
        $view = View::forge('ahome/about');
        $this->template->title = 'About Us';
        $this->template->content = $view;
    }
	public function action_comment($id)
	{
		$attraction = Model_Attraction::find_by_id($id);
		
		// Lazy validation
		if (Input::post('name') AND Input::post('email') AND Input::post('message'))
		{
			// Create a new comment
			$attraction->comments[] = new Model_Comment(array(
				'name' => Input::post('name'),
				'email' => Input::post('email'),
				'message' => Input::post('message'),
				'user_id' => $this->current_user->id,
			));
			
			// Save the post and the comment will save too
			if ($attraction->save())
			{
				$comment = end($attraction->comments);
				Session::set_flash('success', 'Added comment #'.$comment->id.'.');
			}
			else
			{
				Session::set_flash('error', 'Could not save comment.');
			}
			
			Response::redirect('ahome/view/'.$id);
		}
		
		// Did not have all the fields
		else
		{
			// Just show the view again until they get it right
			$this->action_view($id);
		}
	}
	
	public function action_buy_brochure($hash = null)
	{
		
		$this->template->title = 'Buy Travel Brochures';
		$this->template->content = View::forge('ahome/buy_brochure');

		if ( ! Auth::check())
		{
			Session::set_flash('error', e('You must be logged in to purchase brochures!'));
			Response::redirect('admin/login');
		}

		if (\Input::method() == 'POST')
		{
		
				// lookup the user's data from the database
				$name = Auth::get('username');
				$emailaddress = Auth::get('email');
				// get data from the HTML form
				$postaladdress = \Input::post('postaladdress');
				$brochurename = \Input::post('brochurename');	
				
					// send an order confirmation email
					\Package::load('email');
					$email_data = array();
					$email = \Email::forge();
					$email->from('admin@gmail.com', 'CT310 Admin'); 
					$email->to($emailaddress, $name);
					$email->subject('CT310 Project2 Order Confirmation');
					
					
					$email_data['fullname'] = \Input::post('fullname');
					$email_data['order'] = $brochurename;
					$email_data['address'] = $postaladdress;
					
					
					$email->html_body(\View::forge('ahome/emailbrochure', array('email_data' => $email_data)));
					
					// Try sending email
					try
					{
						// send the email
						$email->send();
						Session::set_flash('success', e('Your order confirmation has been sent at your registered email!'));
						\Response::redirect('ahome');
					}
	
					// in case something is wrong
					catch(\EmailValidationFailedException $e)
					{
					
					Session::set_flash('error', e('Invalid email address!'));
					\Response::redirect('ahome');
					}
	
					// what went wrong now?
					catch(\Exception $e)
					{
						
					// Display message 
					Session::set_flash('error', e('Error sending email!'));
					\Response::redirect('ahome');
					}
				
				
		}
	}
	
}
