<?php
class Controller_Admin_States extends Controller_Admin
{

	public function action_index()
	{
		$data['states'] = Model_State::find('all');
		$this->template->title = "States";
		$this->template->content = View::forge('admin/states/index', $data);

	}

	public function action_view($id = null)
	{
		$data['state'] = Model_State::find($id);

		$this->template->title = "State";
		$this->template->content = View::forge('admin/states/view', $data);

	}

	public function action_create()
	{
		if (Input::method() == 'POST')
		{
			$val = Model_State::validate('create');

			if ($val->run())
			{
				$state = Model_State::forge(array(
					'id' => Input::post('id'),
					'name' => Input::post('name'),
				));

				if ($state and $state->save())
				{
					Session::set_flash('success', e('Added state #'.$state->id.'.'));

					Response::redirect('admin/states');
				}

				else
				{
					Session::set_flash('error', e('Could not save state.'));
				}
			}
			else
			{
				Session::set_flash('error', $val->error());
			}
		}

		$this->template->title = "States";
		$this->template->content = View::forge('admin/states/create');

	}

	public function action_edit($id = null)
	{
		$state = Model_State::find($id);
		$val = Model_State::validate('edit');

		if ($val->run())
		{
			$state->id = Input::post('id');
			$state->name = Input::post('name');

			if ($state->save())
			{
				Session::set_flash('success', e('Updated state #' . $id));

				Response::redirect('admin/states');
			}

			else
			{
				Session::set_flash('error', e('Could not update state #' . $id));
			}
		}

		else
		{
			if (Input::method() == 'POST')
			{
				$state->id = $val->validated('id');
				$state->name = $val->validated('name');

				Session::set_flash('error', $val->error());
			}

			$this->template->set_global('state', $state, false);
		}

		$this->template->title = "States";
		$this->template->content = View::forge('admin/states/edit');

	}

	public function action_delete($id = null)
	{
		if ($state = Model_State::find($id))
		{
			$state->delete();

			Session::set_flash('success', e('Deleted state #'.$id));
		}

		else
		{
			Session::set_flash('error', e('Could not delete state #'.$id));
		}

		Response::redirect('admin/states');

	}

}
