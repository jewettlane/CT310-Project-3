<?php
class Controller_Admin_Attractions extends Controller_Admin
{

	public function action_index()
	{
		$data['attractions'] = Model_Attraction::find('all');
		$this->template->title = "Attractions";
		$this->template->content = View::forge('admin/attractions/index', $data);

	}

	public function action_view($id = null)
	{
		$data['attraction'] = Model_Attraction::find($id);

		$this->template->title = "Attraction";
		$this->template->content = View::forge('admin/attractions/view', $data);

	}

	public function action_create()
	{
		if (Input::method() == 'POST')
		{
			$val = Model_Attraction::validate('create');

			if ($val->run())
			{
				$attraction = Model_Attraction::forge(array(
					'title' => Input::post('title'),
					'id' => Input::post('id'),
					'image_url' => Input::post('image_url'),
					'summary' => Input::post('summary'),
					'body' => Input::post('body'),
					'state_id' => Input::post('state_id'),
					'user_id' => Input::post('user_id'),
				));

				if ($attraction and $attraction->save())
				{
					Session::set_flash('success', e('Added attraction #'.$attraction->id.'.'));

					Response::redirect('admin/attractions');
				}

				else
				{
					Session::set_flash('error', e('Could not save attraction.'));
				}
			}
			else
			{
				Session::set_flash('error', $val->error());
			}
		}

		$this->template->title = "Attractions";
		$this->template->content = View::forge('admin/attractions/create');

	}

	public function action_edit($id = null)
	{
		$attraction = Model_Attraction::find($id);
		$val = Model_Attraction::validate('edit');

		if ($val->run())
		{
			$attraction->title = Input::post('title');
			$attraction->id = Input::post('id');
			$attraction->image_url = Input::post('image_url');
			$attraction->summary = Input::post('summary');
			$attraction->body = Input::post('body');
			$attraction->state_id = Input::post('state_id');
			$attraction->user_id = Input::post('user_id');

			if ($attraction->save())
			{
				Session::set_flash('success', e('Updated attraction #' . $id));

				Response::redirect('admin/attractions');
			}

			else
			{
				Session::set_flash('error', e('Could not update attraction #' . $id));
			}
		}

		else
		{
			if (Input::method() == 'POST')
			{
				$attraction->title = $val->validated('title');
				$attraction->id = $val->validated('id');
				$attraction->image_url = $val->validated('image_url');
				$attraction->summary = $val->validated('summary');
				$attraction->body = $val->validated('body');
				$attraction->state_id = $val->validated('state_id');
				$attraction->user_id = $val->validated('user_id');

				Session::set_flash('error', $val->error());
			}

			$this->template->set_global('attraction', $attraction, false);
		}

		$this->template->title = "Attractions";
		$this->template->content = View::forge('admin/attractions/edit');

	}

	public function action_delete($id = null)
	{
		if ($attraction = Model_Attraction::find($id))
		{
			$attraction->delete();

			Session::set_flash('success', e('Deleted attraction #'.$id));
		}

		else
		{
			Session::set_flash('error', e('Could not delete attraction #'.$id));
		}

		Response::redirect('admin/attractions');

	}

}
