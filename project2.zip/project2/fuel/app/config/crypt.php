<?php
return array (
  'crypto_key' => 'yfYwTMUSERCovtMtGAsdsIds',
  'crypto_iv' => 'Ko4zzk7_Aj30lTc3TYKtQdEU',
  'crypto_hmac' => 'WMkDG4aTY5rIAJIGmwhOQvIc',
);
