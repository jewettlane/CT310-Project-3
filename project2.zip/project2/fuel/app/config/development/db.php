<?php
/**
 * The development database settings. These get merged with the global settings.
 */

return array(
	'default' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=faure.cs.colostate.edu;dbname=jewett',
			'username'   => 'jewett',
			'password'   => '830587185',
		),
	),
);
