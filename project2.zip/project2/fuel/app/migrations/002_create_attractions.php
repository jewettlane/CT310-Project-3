<?php

namespace Fuel\Migrations;

class Create_attractions
{
	public function up()
	{
		\DBUtil::create_table('attractions', array(
			'title' => array('constraint' => 255, 'type' => 'varchar'),
			'id' => array('constraint' => 11, 'type' => 'int'),
			'image_url' => array('constraint' => 100, 'type' => 'varchar'),
			'summary' => array('constraint' => 200, 'type' => 'varchar'),
			'body' => array('type' => 'text'),
			'state_id' => array('constraint' => 11, 'type' => 'int'),
			'user_id' => array('constraint' => 11, 'type' => 'int'),
			'created_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),
			'updated_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),

		), array('id'));
	}

	public function down()
	{
		\DBUtil::drop_table('attractions');
	}
}